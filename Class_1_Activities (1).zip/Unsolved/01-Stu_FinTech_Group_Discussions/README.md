# FinTech and Me

So far, today has been all about course introductions and lectures. Now it's time to reflect a bit about the following question: what does FinTech mean to you?

## Instructions

Answer the following questions:

* What does FinTech mean to you? Why is it important?

* What about FinTech interests you?

* Where do you expect FinTech to take you? What are you looking to do?

* What about FinTech may be confusing? What makes sense?

Write down your answers and keep them somewhere safe. In the future, we will look back at your responses to see how much you've accomplished!

---

© 2020 Trilogy Education Services, a 2U, Inc. brand. All Rights Reserved.
